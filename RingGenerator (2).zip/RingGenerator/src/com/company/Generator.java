package com.company;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Generator {

    Generator(){

        points = new ArrayList<>();

    }

    int numPoints = 200;
    int numRotations = 360;
    ArrayList<Point3D> points;

    double radius = 15;
    double tolerance = 1;
    Point3D center = new Point3D(100,100,0);

    //=================================================================

    void generate(){

        for(double x_coord = 0; x_coord < numPoints; x_coord+=0.1){

            for(double y_coord = 0; y_coord < numPoints; y_coord+=0.1){

                //double x_pos = Math.sqrt(Math.abs(Math.pow(radius,2) - Math.pow((y_coord-center.y),2))) + center.x;
                //double y_pos = Math.sqrt(Math.abs(Math.pow(radius,2) - Math.pow((x_coord-center.x),2))) + center.y;

                double equation = Math.pow((x_coord - center.x),2) + Math.pow((y_coord - center.y),2);

                if(equation >= (Math.pow(radius,2) - tolerance) && equation < (Math.pow(radius,2) + tolerance))
                    points.add(new Point3D(x_coord, y_coord, 0));

            }


        }
    }

    //=================================================================

    void rotateExtrude(){

        ArrayList<Point3D> rotated = new ArrayList<>();

        for(int i = 0; i < numRotations; i++){

            //rotated = new ArrayList<>();

            for(Point3D p : points){

                double rotated_x = p.x * Math.cos(i) - p.z * Math.sin(i);
                double rotated_z = p.z * Math.cos(i) + p.x * Math.sin(i);

                rotated.add(new Point3D(rotated_x, p.y, rotated_z));

            }

        }

        points.clear();
        points.addAll(rotated);

    }

    void saveFile() throws IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"));

        for(Point3D point : points){

            bw.write("" + point.x + ";" + point.y + ";" + point.z + "\n");

        }

        bw.close();

    }

}
