package com.company;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
	// write your code here

    Generator gen = new Generator();

    gen.generate();
    gen.rotateExtrude();
    gen.saveFile();

    }
}
