package com.company;

public class Point3D {

    Point3D(double x, double y, double z){

        this.x = x;
        this.y = y;
        this.z = z;

    }

    double x = 0;
    double y = 0;
    double z = 0;

}
